
Thank you for downloading my MSFS Light Mod Pack!
Get updates at https://uwajimaya.github.io/FS2020/ and post/message me at my site or on https://www.avsim.com/ or https://forums.flightsimulator.com/

- Uwajimaya

###### Please delete any previous versions of Uwa light mods before intalling this package! ######

All packs includes updated landing, taxi, strobe, nav, and beacon lights


Pack version 1.01 (Sept.23, 2020)

- Icon A5 (LED lights, added rear wing white nav lights, added simulated strobe lens flare)
- C152 (regular lights, added simulated strobe lens flare). Does NOT work with the C152 Aerobat


Pack version 1.0 (Sept.20, 2020)

- Bonanza G36
- Cessna 172 (G1000) w.LED lights
- Cessna 208 Grand Caravan
- Cessna CJ4 Citation
- Diamond DA62
- Diamond DA40 NG
- King Air 350
- TBM 930

HOW TO INSTALL:
Unzip and place the "Uwa light mod pack" folder in your ... \Microsoft Flight Simulator\Packages\Community folder

Direcotry location:
MS Store Version: %homepath%\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\

Steam Version: %homepath%\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\

HOW TO UNINSTALL
Delete the "Uwa light mod pack" folder from your ...Packages\Community folder.

