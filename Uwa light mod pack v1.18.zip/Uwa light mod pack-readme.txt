
Thank you for downloading my MSFS Light Mod Pack!
Get updates at https://uwajimaya.github.io/FS2020/ and post/message me at my site or on https://www.avsim.com/ or https://forums.flightsimulator.com/

Please credit my work if you use it in your mods (and asking for permission to use it is a nice gesture, too)

- Uwajimaya

###### Please delete any previous versions of Uwa light mods before intalling this package! ######

All packs includes updated landing, taxi, strobe, nav, and beacon lights

Pack version 1.18(Dec 26, 2021)
-Added the NXCub

Pack version 1.17(Dec 14, 2021)
-Added the F/A-18

Pack version 1.16(Dec 5, 2021)
-Added all version of the PC6

Pack version 1.15(Sep 8, 2021)
- Updated XCub landing/pulse light
- Replaced default lights on XCub Floats & Skis, replaced default lights on C172(G1000) Floats & Skis

Pack version 1.14(Jun 28, 2021)
- Fixed 747 red wing light intensity
- Compatible with latest Patch

Pack version 1.13 (Feb 16, 2021)
- Updated King Air 350 beacons, light no longer bleeds into cabin. 
- Compatible with Patch 1.13.16.0)

Pack version 1.12 (Dec 27, 2020)
- Small fixes throughout where Asobo changes in electrical and other systems did not properly appear in my mod

Pack version 1.11 (Dec 22,2020)
- Compatible with Patch 1.12.13.0  

Pack version 1.10 (Nov 22,2020) 
- Compatible with Patch 1.11.6.0 

Pack version 1.09 (Nov 9, 2020)
- Added dedicated volumetric taxi and landing lights to default A320 (not compatible with 320NX), B747, Cap10, DR400, E300, Savage Cup, XCup

Pack version 1.08 (Oct 29, 2020)
- Compatible with Update 5/Patch 1.10.4. Added dedicated volumetric taxi and landing lights to DA62, DA40NG, Icon A5

Pack version 1.07 (Oct 25, 2020)
- Added dedicated volumetric taxi and landing lights to VL-3, C152, C172

Pack version 1.06 (Oct 15, 2020)
- Added dedicated volumetric taxi and landing lights to TBM, King Air, C208, Bonanza G36 and CJ4. You see them in fog and clouds, but they're low intensity and small enough to not make them looks ridicilous outside of clouds.

Pack version 1.05 (Oct 10, 2020)
- Added Boeing 747-8. Note: there is a bug/missing feature with the nose landing gear - it will not automatically turn off when retracted and light up the inside of the cockpit (you can't miss it...). Just turn turn it off manually.
- Added VL-3, Savage Cup, Extra 330
- added ice light to Diamond D62 (missing from defalut D62, thx MrTommymxr)

Pack version 1.04 (Oct 4, 2020)
- Added XCub, DR400, Cap10 
- seperated each a/c into its own folder to allow easier user modification/deletion and thus avoid conflict with other mods (e.g. If you have the A320NX mod, simply delete the "Uwa light mod - A320" folder from your community folder.)

Pack version 1.03 (Oct 2, 2020)
- simplified strobe lens flare and applied to all a/c; simplified beacon lens flare and applied to all a/c with beacons; removed static lens flare from all a/c; adjusted landing/taxi light color and applied to all a/c.

Pack version 1.02 (Sept 27, 2020) 
- A320 Neo, C208 update 

Pack version 1.01 (Sept.23, 2020)
- Icon A5, C152 (Does NOT work with the premium/delux C152 Aerobat)

Pack version 1.0 (Sept.20, 2020)
- Bonanza G36, Cessna 172 (G1000) (Does NOT work with the premium/delux C172 Classic), Cessna 208 Grand Caravan, Cessna CJ4 Citation, Diamond DA62, Diamond DA40 NG, King Air 350, TBM 930

HOW TO INSTALL:
Unzip and place all "Uwa light mod" folders in your ... \Microsoft Flight Simulator\Packages\Community folder.

Direcotry location:
MS Store Version: %homepath%\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\

Steam Version: %homepath%\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\

HOW TO UNINSTALL
Delete the "Uwa light mod" folder(s) from your ...Packages\Community folder.

