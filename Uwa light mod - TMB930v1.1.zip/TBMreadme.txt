
Thank you for downloading my TMB930 lighting mod! (Thanks to sfdeham for testing)
Get my other lighting mods at https://uwajimaya.github.io/FS2020/ and post or message me on https://forums.flightsimulator.com/ for questions. 

- Uwajimaya


HOW TO INSTALL:
If you have the previous version in your community folder ("TBM930 lighting update"), simply delete the "TBM930 lighting update" folder.

Unzip and place the "Uwa light mod - TMB930" folder in your ... \Microsoft Flight Simulator\Packages\Community folder
(Don't know where your community folder is? Watch the first 2 minutes of this helpful video: https://www.youtube.com/watch?v=kAYf6Anaxgo)

HOW TO UNINSTALL
Delete the "Uwa light mod - TMB930" folder from your ...Packages\Community folder.


v1.1 (Sept 9,2020)
- Renamed the .fx files so the lighting effects apply only to the TBM (in v1.0, they applied globally)
- Changed the folder name of my mod to "Uwa light mod -[a/c name] so if you install more than one, they're all sequential instead of mixed in with other mods and difficult to find/remember.
- gave the strobe light a light blue hue to give it XEON feel.

v1.0 (Sept 7,2020)
Strobelights:
Modified LIGHT_ASOBO_StrobeSimple.fx to speed up the flash sequence, made the strobe lights brighter, and changed the strobe to be volumetric so you can see it reflected when flying in clouds!

Taxi lights:
Modified LIGHT_ASOBO_Taxi.fx so that the taxi light/lighting "cone" is a lot narrower and a bit brighter. Also modified the TBM930 systems.cfg so that taxi lights shine inward towards the fuselage/centerline and a little further ahead. Also made it so that the taxi lights stay on when the landing lights are switched on. Note: By default, these lights are set to be volumetric. That looks great when reflecting of clouds, but outside of that it looks like you're flying in fog/pea soup. So I disabled volumetric for taxi & landing lights.

Landing lights:
Modified LIGHT_ASOBO_Landing.fx so that the landing light/lighting "cone" is a lot wider and a lot brighter. Also modified the TBM systems.cfg so that the landing lights shine a bit inward and a lot further ahead. Note: By default, these lights are set to be volumetric. That looks great when reflecting of clouds, but outside of that it looks like you're flying in fog/pea soup. So I disabled volumetric for taxi & landing lights.

Nav lights:
Modified both LIGHT_ASOBO_NavigationRed.fx and LIGHT_ASOBO_NavigationGreen.fx so that the lights are just bright enough to be reflected off the ground at night - you get little red and green glows.
