
Thank you for downloading my Bonanza G36 lighting mod! 
If you want the lights and an improved flight model, visit the G36 Project at https://github.com/TheFrett/msfs_g36_project. My lighting mod is included in the G36 project, no need to install it separately.

Get my other lighting mods at https://uwajimaya.github.io/FS2020/ and post or message me on https://forums.flightsimulator.com/ for questions. 


- Uwajimaya


HOW TO INSTALL:
Unzip and place the "Uwa light mod - Bonanza G36" folder in your ... \Microsoft Flight Simulator\Packages\Community folder

Directory location:
MS Store Version: %homepath%\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\

Steam Version: %homepath%\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\

OR watch the first 2 minutes of this helpful video: https://www.youtube.com/watch?v=kAYf6Anaxgo

HOW TO UNINSTALL
Delete the "Uwa light mod - Bonanza G36" folder from your ...Packages\Community folder.


v1.0 (Sept 14,2020)

- Strobe lights: Sped up the flash sequence, made the strobe lights brighter, and changed the strobe to be volumetric so you can see it reflected when flying in clouds!

- Taxi and landing lights: increased brightness, range and tilted them upwards for additional range. Disabled default volumetric setting - it looks great when flying inside clouds, but outside of clouds it looks like you're flying in fog/pea soup. With this mod, you will not see taxi and landing lights reflected when inside clouds!

-Nav lights: Made them a bit brighter, just bright enough to be reflected off the ground at night - you get little red and green glows.
