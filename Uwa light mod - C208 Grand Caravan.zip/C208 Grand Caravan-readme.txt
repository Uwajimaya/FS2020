
Thank you for downloading my C208 Grand Caravan lighting mod! 
Get my other lighting mods at https://uwajimaya.github.io/FS2020/ and post or message me on https://forums.flightsimulator.com/ for questions. 


- Uwajimaya


HOW TO INSTALL:
Unzip and place the "Uwa light mod - C208 Grand Caravan" folder in your ... \Microsoft Flight Simulator\Packages\Community folder

Direcotry location:
MS Store Version: %homepath%\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Local\Packages\Microsoft.FlightSimulator_8wekyb3d8bbwe\LocalCache\Packages\Community\

Steam Version: %homepath%\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\
Or more directly: C:\Users\<yourusernamefolder>\AppData\Roaming\Microsoft Flight Simulator\Packages\Community\

OR watch the first 2 minutes of this helpful video: https://www.youtube.com/watch?v=kAYf6Anaxgo

HOW TO UNINSTALL
Delete the "Uwa light mod - C208 Grand Caravan" folder from your ...Packages\Community folder.


v1.0 (Sept 15,2020)

- Taxi and landing lights:increased brightness, range and tilted them upwards for additional range. Disabled default volumetric setting - it looks great when flying inside clouds, but outside of clouds it looks like you're flying in fog/pea soup. With this mod, you will not see taxi and landing lights reflected when inside clouds!

- Strobe lights: Sped up the flash sequence, made the strobe lights brighter, and changed the strobe to be volumetric so you can see it reflected when flying in clouds!

-Nav lights: Made them a bit brighter, just bright enough to be reflected off the ground at night - you get little red and green glows.
