Thank you for downloaing my TMB930 lighting update! Post or message me on https://forums.flightsimulator.com/ for questions. (Thanks to sfdeham for testing)

- Uwajimaya

Installation:
Unzip and place the TMB930 Lighting update" folder in your ... \Microsoft Flight Simulator\Packages\Community folder
(Don't know where your community folder is? Watch the first 2 minutes of this helpful video: https://www.youtube.com/watch?v=kAYf6Anaxgo)

v1.0:
Strobelights:
Modified LIGHT_ASOBO_StrobeSimple.fx to speed up the flash sequence, made the strobe lights brigther, and changed the strobe to be volumetric so you can see it reflected when flying in clouds!

Taxi lights:
Modified LIGHT_ASOBO_Taxi.fx so that the taxi light/lighting "cone" is a lot narrower and a bit brighter. Also modified the TBM930 systems.cfg so that taxi lights shine inward towards the fuselage/centerline and a little further ahead. Also made it so that the taxi lights stay on when the landing lights are switched on. Note: By default, these lights are set to be volumeteric. That looks great when refelcting of clouds, but outside of that it looks like you're flying in fog/pea soup. So I disabled volumetric for taxi & landing lights.

Landing lights:
Modified LIGHT_ASOBO_Landing.fx so that the landing light/lighting "cone" is a lot wider and a lot brighter. Also modified the TBM systems.cfg so that the landing lights shine a bit inward and a lot further ahead.Note: By default, these lights are set to be volumeteric. That looks great when refelcting of clouds, but outside of that it looks like you're flying in fog/pea soup. So I disabled volumetric for taxi & landing lights.

Nav lights:
Modified both LIGHT_ASOBO_NavigationRed.fx and LIGHT_ASOBO_NavigationGreen.fx so that the lights are just bright enough to be reflected off the ground at night - you get little red and green glows.