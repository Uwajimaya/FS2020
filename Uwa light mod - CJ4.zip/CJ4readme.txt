
Thank you for downloading my Cessna Citation 4 lighting mod! 
Get my other lighting mods at https://uwajimaya.github.io/FS2020/ and post or message me on https://forums.flightsimulator.com/ for questions. 

- Uwajimaya


HOW TO INSTALL:
Unzip and place the "Uwa light mod - CJ4" folder in your ... \Microsoft Flight Simulator\Packages\Community folder
(Don't know where your community folder is? Watch the first 2 minutes of this helpful video: https://www.youtube.com/watch?v=kAYf6Anaxgo)

HOW TO UNINSTALL
Delete the "Uwa light mod - CJ4" folder from your ...Packages\Community folder.


v1.0 (Sept 9,2020)
- Named all the .fx files so the lighting effects apply only to the CJ4

-Tail beacon: changed it from the default flash to more of a pulsating light which is closer to the real behavior.

- Strobe lights: Sped up the flash sequence, made the strobe lights brighter, and changed the strobe to be volumetric so you can see it reflected when flying in clouds!

- Taxi and landing lights:increased brightness, range and tilted them upwards for additional range. There is a small issue when turning on the landing lights, you'll see a tiny strip of light on the floor, inside the cockpit. I could make it go away by tilting the lights downward or making them smaller - but then we're back to not as much light as we want. NOTE: By default, these lights are set to be volumetric. That looks great when flying inside clouds, but outside of clouds it looks like you're flying in fog/pea soup. So I disabled volumetric for taxi & landing lights.

-Nav lights: Made them a bit brighter, just bright enough to be reflected off the ground at night - you get little red and green glows.
